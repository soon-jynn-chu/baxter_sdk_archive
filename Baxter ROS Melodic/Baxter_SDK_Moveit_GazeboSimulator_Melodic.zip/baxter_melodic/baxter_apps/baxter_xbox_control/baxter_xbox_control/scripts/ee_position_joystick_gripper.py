#!/usr/bin/env python
"""Baxter End Effector Controller Demo by Jackie Kay (jackie@osrfoundation.org)
Based on the Baxter RSDK Joint Position Example

Command the (x, y, z) position of the end effector using the joystick. Uses
Jacobian kinematics to determine required joint angles. 

"""

# TODO: refactor to use ik_command.py

import argparse
import rospy
import struct
import tf
import copy

import baxter_interface
import baxter_demos

from baxter_interface import CHECK_VERSION

from baxter_pykdl import baxter_kinematics

from operator import add

import numpy as np
from math import atan2, asin

from geometry_msgs.msg import (
    PoseStamped,
    Pose,
    Point,
    Quaternion,
)
from std_msgs.msg import Header
from baxter_core_msgs.srv import (
    SolvePositionIK,
    SolvePositionIKRequest,
)

left_start_position = {
 'left_s0': -0.713684560748291,
 'left_s1': -0.728640873413086,
 'left_w0': -0.041033986029052734,
 'left_w1': 0.8291166149047852,
 'left_w2': 0.03067961572265625,
 'left_e0': 0.07708253450317383,
 'left_e1': 1.145883647241211}

right_start_position = {
 'right_s0': 0.713684560748291,
 'right_s1': -0.728640873413086,
 'right_w0': 0.041033986029052734,
 'right_w1': 0.8291166149047852,
 'right_w2': -0.03067961572265625,
 'right_e0': -0.07708253450317383,
 'right_e1': 1.145883647241211}

untuck_lposition = {
 'left_s0': -0.08,
 'left_s1': -1.0,
 'left_e0': -1.19,
 'left_e1': 1.94,
 'left_w0': 0.67,
 'left_w1': 1.03,
 'left_w2': -0.50}
untuck_rposition= {
 'right_s0': 0.08,
 'right_s1': -1.0,
 'right_e0': 1.19,
 'right_e1': 1.94,
 'right_w0': -0.67,
 'right_w1': 1.03,
 'right_w2': 0.50}
 
 # step for inc/dec

inc=0.02 #global_rotate_speed
global_rotate_speed = 0.02
global_speed_factor = 0.005
#control mode 0 translation, 1 rotation
current_mode = 0
# gripper open indicator, 0 gripper closed, 1 gripper open 
rgripper_open=1 
lgripper_open=1

import cv2
import cv_bridge
import rospkg
from sensor_msgs.msg import (
    Image,
    JointState,
)
rp = rospkg.RosPack()
images = (rp.get_path('baxter_xbox_control') +
                  '/images/')
path = rp.get_path('baxter_xbox_control') + '/config/'

width        = 1024                    
height       = 600
# colours
white = (255, 255, 255)
black = (0, 0, 0)
yellow= (0,255,255)
red=(0,0,255)
customColor=(249,28,221)

# create image publisher to head monitor
pub = rospy.Publisher('/robot/xdisplay', Image, latch=True)
# Convert the last 4 entries in q from quaternion form to Euler Angle form and copy into p
# Expect a 7x1 column vector and a preallocated 6x1 column vector (numpy)
# p and q are both pose vectors
def quaternion_to_euler(q, p):
    if q.shape != (7, 1) or p.shape != (6, 1):
        raise Exception("Got unexpected vector dimension in quaternion_to_euler")
    p[0:3] = q[0:3]
    p[3], p[4], p[5] = tf.transformations.euler_from_quaternion(q[3:7].flatten().tolist())


def start_position():
    left = baxter_interface.Limb('left')
    right = baxter_interface.Limb('right')
    left.move_to_joint_positions(left_start_position) 
    right.move_to_joint_positions(right_start_position)       
    
        
def untuck_position():
    left = baxter_interface.Limb('left')
    right = baxter_interface.Limb('right')
    left.move_to_joint_positions(untuck_lposition) 
    right.move_to_joint_positions(untuck_rposition)

def l_toggleGripper():
    global lgripper_open
    l_gripper = baxter_interface.Gripper('left', CHECK_VERSION)
    if lgripper_open==0 :
        l_gripper.open() 
        lgripper_open=1
        print ('Left Gripper opened!') 
        print l_gripper.position()  

    elif lgripper_open==1 :
        l_gripper.close()
        lgripper_open=0
        print ('Left Gripper closed!')
        print l_gripper.position() 

            
def r_toggleGripper():
    global rgripper_open
    r_gripper = baxter_interface.Gripper('right', CHECK_VERSION)
    if rgripper_open==0 :
        r_gripper.open() 
        rgripper_open=1
        print ('Right Gripper opened!')
        print r_gripper.position()  

    elif rgripper_open==1 :
        r_gripper.close()
        rgripper_open=0
        print ('Right Gripper closed!')
        print r_gripper.position() 

                
def adjust_speed(global_factor):
    global inc
    global global_speed_factor
    global global_rotate_speed

    if (current_mode==0):
        inc+=global_factor
        if (inc<0):
            inc=0
    else:
        global_rotate_speed+=global_factor
        if (global_rotate_speed<0):
            global_rotate_speed=0     
       
    printControlState()
    
def switch_mode():
    global current_mode
    if (current_mode==0):
        current_mode=1
    else:
        current_mode=0
    printControlState()
              
def printControlState():
        if (current_mode==0):
        
	    print("\nControling %s  ..." % "translation")
	else :
	    print("\nControling %s  ..." % "rotation")	
	print("Move speed is: %.3lf meter per press" % inc)
	print("Rotate speed is: %.3lf radius per press" % global_rotate_speed)	

def rotateLimb(limbPose,current_rotation,clockwise):
	#global current_rotation
	global global_rotate_speed
	#global limbPoseStamped
	
	quaternion = (
		limbPose['orientation'].x,
		limbPose['orientation'].y,
		limbPose['orientation'].z,
		limbPose['orientation'].w,
	)
	euler = tf.transformations.euler_from_quaternion(quaternion)
	
	target_rotate_speed = copy.copy(global_rotate_speed)
	if not clockwise:
		target_rotate_speed = -target_rotate_speed
		
	r = 0
	p = 0
	y = 0
	if (current_rotation == 'x'):
		r = target_rotate_speed
	elif (current_rotation == 'y'):
		p = target_rotate_speed
	elif (current_rotation == 'z'):
		y = target_rotate_speed
		
	quaternion = tf.transformations.quaternion_from_euler(euler[0] + r, euler[1] + p, euler[2] + y)
	print quaternion
	orientationList=[]
	orientationList.append(quaternion[0])
	orientationList.append(quaternion[1])
	orientationList.append(quaternion[2])
	orientationList.append(quaternion[3])
        print orientationList
	print 'rotated...'
	#print type(quaternion)
	#print type(limbPose['position'])
	return np.array(limbPose['position']+tuple(quaternion))
	

    
def command_ik(side,xyz,offset):
    global inc
    """Use the Rethink IK service to figure out a desired joint position
       This is way too slow to use in realtime. Unless I figure out why the
       IK service takes minutes to respond, not going to use it."""
  
    #Connect with IK service
    right_ns = "ExternalTools/right/PositionKinematicsNode/IKService"
    right_iksvc = rospy.ServiceProxy(right_ns, SolvePositionIK)
    left_ns = "ExternalTools/left/PositionKinematicsNode/IKService"
    left_iksvc = rospy.ServiceProxy(left_ns, SolvePositionIK)
    left = baxter_interface.Limb('left')
    right = baxter_interface.Limb('right')

    if side == 'left':
        limb = left
        iksvc = left_iksvc
        ns = left_ns
        limb.set_joint_position_speed(0.8)
    else:
        limb = right
        iksvc = right_iksvc
        ns = right_ns
        limb.set_joint_position_speed(0.8)
        
    clockwise = True
    clockwise = True if offset==1 else False
    
    if (current_mode==0):     
        zeros = [0]*4    
        if (xyz=='x'):
            direction=[offset*inc, 0, 0]+zeros
        elif (xyz=='y'):
            direction=[ 0, offset*inc, 0]+zeros   
        elif (xyz=='z'):
            direction=[ 0, 0, offset*inc]+zeros       
        
        current_p = np.array(limb.endpoint_pose()['position']+limb.endpoint_pose()['orientation']) 
        #print type(limb.endpoint_pose()['position'])
        #print type(limb.endpoint_pose()['orientation'])
        #print type (current_p)
        #print limb.endpoint_pose()
        direction = np.array(direction)
        #print ("current direc" + str(direction))
        desired_p = current_p + direction
    else:
        limbPose=limb.endpoint_pose()
        if (xyz=='x'):
            desired_p= rotateLimb(limbPose,'x',clockwise)            
        elif (xyz=='y'):
            desired_p= rotateLimb(limbPose,'y',clockwise)            
        elif (xyz=='z'):
            desired_p= rotateLimb(limbPose,'z',clockwise)
    print "desired position: " + str(desired_p)
    ikreq = SolvePositionIKRequest()
    hdr = Header(stamp=rospy.Time.now(), frame_id='base')
    pose = { side : PoseStamped(
                header = hdr,
                pose = Pose(position=Point(x=desired_p[0], y=desired_p[1], z=desired_p[2]),
                orientation = Quaternion(x=desired_p[3], y=desired_p[4], z=desired_p[5], w=desired_p[6]))
            ) }

    ikreq.pose_stamp.append(pose[side])
    try:
        rospy.wait_for_service(ns, 5.0)
        resp = iksvc(ikreq)
    except (rospy.ServiceException, rospy.ROSException), e:
        rospy.logerr("Service call failed: %s" % (e,))
        return
    print "Got response from IK service"
    #resp_seeds = struct.unpack('<%dB' % len(resp.result_type),
    #                           resp.result_type)
    if (resp.isValid[0]): #resp_seeds[0] != resp.RESULT_INVALID
        limb_joints = dict(zip(resp.joints[0].name, resp.joints[0].position))
        #limb.set_joint_position_speed(0.8)        
        #limb.move_to_joint_positions(limb_joints)
        limb.set_joint_positions(limb_joints)               
    else:
        #How to recover from this
        return

# Get key commands from the user and move the end effector
def map_joystick(joystick):
    global inc
    global global_speed_factor
    global current_mode
    global global_rotate_speed
    global rgripper_open, lgripper_open
    
    left = baxter_interface.Limb('left')
    right = baxter_interface.Limb('right')
    grip_left = baxter_interface.Gripper('left', CHECK_VERSION)
    grip_right = baxter_interface.Gripper('right', CHECK_VERSION)
    
    #abbreviations
    jhi = lambda s: joystick.stick_value(s) > 0
    jlo = lambda s: joystick.stick_value(s) < 0
    bdn = joystick.button_down
    bup = joystick.button_up

    #zeros = [0]*4
    #inc = 0.1

    def print_help(bindings_list):
        helpstr=""
        print("Press Ctrl-C to quit.")
        for bindings in bindings_list:
            for (test, _cmd, doc) in bindings:
                if callable(doc):
                    doc = doc()
                helpstr += '\n' + str(test[1][0]) + ":" + doc                    
                print("%s: %s" % (str(test[1][0]), doc))
        splash_screen1(helpstr)

    bindings_list = []
    bindings = (
        ((bdn, ['rightTrigger']),
         (l_toggleGripper,  []), lambda: "left hand: gripper open" if lgripper_open==1 else "left hand: gripper close" ),
        #((bup, ['rightTrigger']),
         #(grip_left.open,   []), "left hand: gripper open"),
        ((bdn, ['leftTrigger']),
         (r_toggleGripper, []), lambda:"right hand: gripper open" if rgripper_open==1 else "right hand: gripper close"),
        #((bup, ['leftTrigger']),
         #(grip_right.open,  []), "right hand: gripper open"),
        ((jlo, ['leftStickHorz']),
         (command_ik, ['right','y',1]), lambda: "right hand:y inc %.3lf meters " %inc if current_mode==0 else "right hand y:rotate inc %.3lf rads" %global_rotate_speed ),
        ((jhi, ['leftStickHorz']),
         (command_ik, ['right', 'y',-1]), lambda: "right hand:y dec %.3lf meters " %inc if current_mode==0 else "right hand y:rotate dec %.3lf rads" %global_rotate_speed),
        ((jlo, ['leftStickVert']),
         (command_ik, ['right','x',1]), lambda: "right hand:x inc %.3lf meters " %inc if current_mode==0 else "right hand x:rotate inc %.3lf rads" %global_rotate_speed),
        ((jhi, ['leftStickVert']),
         (command_ik, ['right','x',-1]), lambda: "right hand:x dec %.3lf meters " %inc if current_mode==0 else "right hand x:rotate dec %.3lf rads" %global_rotate_speed),
        ((bdn, ['dPadUp']),
         (command_ik, ['right','z',1]), lambda: "right hand:z inc %.3lf meters" %inc if current_mode==0 else "right hand z:rotate inc %.3lf rads" %global_rotate_speed),
        ((bdn, ['dPadDown']),
         (command_ik, ['right','z',-1]), lambda: "right hand:z dec %.3lf meters" %inc if current_mode==0 else "right hand z:rotate dec %.3lf rads" %global_rotate_speed),
         
        ((bdn, ['dPadRight']),
         (adjust_speed, [global_speed_factor]), lambda:"increase speed to: %.3lf meters per press" %inc if current_mode==0 else "increase speed to: %.3lf rads per press" %global_rotate_speed),
         
        ((bdn, ['dPadLeft']),
         (adjust_speed, [-global_speed_factor]), lambda:"decrease speed to: %.3lf meters per press" %inc if current_mode==0 else "decrease speed to: %.3lf rads per press" %global_rotate_speed),  
                  
        ((jlo, ['rightStickHorz']),
         (command_ik, ['left', 'y',1]), lambda: "left hand:y inc %.3lf meters " %inc if current_mode==0 else "left hand y:rotate inc %.3lf rads" %global_rotate_speed),
        ((jhi, ['rightStickHorz']),
         (command_ik, ['left', 'y',-1]), lambda: "left hand:y dec %.3lf meters " %inc if current_mode==0 else "left hand y:rotate dec %.3lf rads" %global_rotate_speed),
        ((jlo, ['rightStickVert']),
         (command_ik, ['left', 'x',1]), lambda: "left hand:x inc %.3lf meters " %inc if current_mode==0 else "left hand x:rotate inc %.3lf rads" %global_rotate_speed),
        ((jhi, ['rightStickVert']),         
         (command_ik, ['left', 'x',-1]), lambda: "left hand:x dec %.3lf meters " %inc if current_mode==0 else "left hand x:rotate dec %.3lf rads" %global_rotate_speed),
        ((bdn, ['btnUp']),
         (command_ik, ['left', 'z',1]), lambda: "left hand:z inc %.3lf meters " %inc if current_mode==0 else "left hand z:rotate inc %.3lf rads" %global_rotate_speed),
        ((bdn, ['btnDown']),
         (command_ik, ['left', 'z',-1]), lambda: "left hand:z dec %.3lf meters " %inc if current_mode==0 else "left hand z:rotate dec %.3lf rads" %global_rotate_speed),
        ((bdn, ['btnRight']),
         (start_position, []), "left & right:start position"),
         
        ((bdn, ['btnLeft']),
         (untuck_position, []), "left & right:untuck position"),            
                        
        ((bdn, ['rightBumper']),
         (grip_left.calibrate, []), "left hand:calibrate"),
        ((bdn, ['leftBumper']),
         (grip_right.calibrate, []), "right hand:calibrate"),
        ((bdn, ['function1']),
         (switch_mode, []), lambda: "switch mode:translation" if current_mode==0 else "switch mode:rotation" ),
        ((bdn, ['function2']),
         (print_help, [bindings_list]), lambda:"help:current in translation" if current_mode==0 else "help:current in rotation"),
        )
    bindings_list.append(bindings)

    rate = rospy.Rate(500)
    print_help(bindings_list)
    print("Press Ctrl-C to stop. ")
    while not rospy.is_shutdown():
        for (test, cmd, doc) in bindings:
            if test[0](*test[1]):
                cmd[0](*cmd[1])
                if callable(doc):
                    print(doc())
                    splash_screen(doc().split(":")[0], doc().split(":")[1])
                    if test[1][0] =="function2":
                        overlayImage(doc().split(":")[0], doc().split(":")[1])                                        
                else:
                    print(doc)
                    splash_screen(doc.split(":")[0], doc.split(":")[1])                                        
        rate.sleep()
    return False
def vertical(side, showinfo=True):
    # may change other joints
    left = baxter_interface.Limb('left')
    right = baxter_interface.Limb('right')
    if side == 'left':
        limb = left

    else:
        limb = right
   
    _pose = limb.endpoint_pose()

    elr = tf.transformations.euler_from_quaternion([
        _pose['orientation'].x,
        _pose['orientation'].y,
        _pose['orientation'].z,
        _pose['orientation'].w])
    qtn = Quaternion()
    qtn.x, qtn.y, qtn.z, qtn.w = tf.transformations.quaternion_from_euler(
        math.pi, 0, elr[2])

    ik_pose = Pose()
    ik_pose.position.x = _pose['position'].x
    ik_pose.position.y = _pose['position'].y
    ik_pose.position.z = _pose['position'].z
    ik_pose.orientation.x = qtn.x
    ik_pose.orientation.y = qtn.y
    ik_pose.orientation.z = qtn.z
    ik_pose.orientation.w = qtn.w

    joints_pose = ik_request(ik_pose,side)
    if type(joints_pose) is bool:
        rospy.logerr('Invalid value, this pose will be passed')
        return
    if showinfo:
        rospy.loginfo('moving to vertial pose...')
        
    limb.set_joint_position_speed(0.8)
    limb.move_to_joint_positions(joints_pose)
    
    
def horizontal(side, showinfo = True):
    # may change other joints
    left = baxter_interface.Limb('left')
    right = baxter_interface.Limb('right')
    if side == 'left':
        limb = left

    else:
        limb = right    
    _pose = limb.endpoint_pose()

    elr = tf.transformations.euler_from_quaternion([
        _pose['orientation'].x,
        _pose['orientation'].y,
        _pose['orientation'].z,
        _pose['orientation'].w])
    qtn = Quaternion()
    qtn.x, qtn.y, qtn.z, qtn.w = tf.transformations.quaternion_from_euler(
        math.pi/2, math.pi, elr[2])

    ik_pose = Pose()
    ik_pose.position.x = _pose['position'].x
    ik_pose.position.y = _pose['position'].y
    ik_pose.position.z = _pose['position'].z
    ik_pose.orientation.x = qtn.x
    ik_pose.orientation.y = qtn.y
    ik_pose.orientation.z = qtn.z
    ik_pose.orientation.w = qtn.w

    joints_pose = ik_request(ik_pose,side)
    if type(joints_pose) is bool:
        rospy.logerr('Invalid value, this pose will be passed')
        return
        
    if showinfo:
        rospy.loginfo('moving to horizontal pose...')
    limb.set_joint_position_speed(0.8)
    limb.move_to_joint_positions(joints_pose)
    
def ik_request(ik_pose, side, use_advanced_options = False):
    hdr = Header(stamp=rospy.Time.now(), frame_id='base')
    ikreq = SolvePositionIKRequest()
    ikreq.pose_stamp.append(PoseStamped(header=hdr, pose=ik_pose))
    #ikreq.tip_names.append('right_hand')
    
    #Connect with IK service
    right_ns = "ExternalTools/right/PositionKinematicsNode/IKService"
    right_iksvc = rospy.ServiceProxy(right_ns, SolvePositionIK)
    left_ns = "ExternalTools/left/PositionKinematicsNode/IKService"
    left_iksvc = rospy.ServiceProxy(left_ns, SolvePositionIK)


    if side == 'left':

        iksvc = left_iksvc
        ns = left_ns
    else:

        iksvc = right_iksvc
        ns = right_ns        
    
    if use_advanced_options:
        ikreq.seed_mode = ikreq.SEED_USER
        seed = JointState()
        seed.name = ['right_j0', 'right_j1', 'right_j2', 'right_j3',
                 'right_j4', 'right_j5', 'right_j6']
        seed.position = [0.7, 0.4, -1.7, 1.4, -1.1, -1.6, -0.4]
        ikreq.seed_angles.append(seed)
        
        ikreq.use_nullspace_goal.append(True)
        goal = JointState()
        goal.name = ['right_j1', 'right_j2', 'right_j3']
        goal.position = [0.1, -0.3, 0.5]
        ikreq.nullspace_gain.append(0.4)
    
    try:
        rospy.wait_for_service(ns, 5.0)
        resp = iksvc(ikreq)
    except (rospy.ServiceException, rospy.ROSException), e:
        rospy.logerr("Service call failed: %s" % (e,))
        return False

    if resp.result_type[0] > 0:
        # print 'SUCCESS-Valid Joint Solution Found:'
        limb_joints = dict(zip(resp.joints[0].name, resp.joints[0].position))
        # print limb_joints
    else:
        rospy.logerr('INVALID POSE - No Valid Joint Solution Found.')
        return False

    return limb_joints
def send_headImage(path):
    splash_array= cv2.imread(path+"2.png")
    msg = cv_bridge.CvBridge().cv2_to_imgmsg(splash_array, encoding="bgr8")
    pub.publish(msg)

# display message on head display
def splash_screen(s1, s2):
    splash_array= cv2.imread(images+"template6.png")
    #splash_array = numpy.zeros((self.height, self.width, 3), numpy.uint8)
    #font = cv2.InitFont(cv2.CV_FONT_HERSHEY_SIMPLEX, 3.0, 3.0, 9)
    fontFace = cv2.FONT_HERSHEY_SIMPLEX
    fontScale = 3
    fontThickness=3
    fontColor = (255, 255, 255)        

    ((text_x, text_y), baseline) = cv2.getTextSize(s1, fontFace,fontScale,fontThickness)
    org = ((width - text_x) / 2, (height / 3) + (text_y / 2)-100)
    cv2.putText(splash_array, s1, org, cv2.FONT_HERSHEY_SIMPLEX, 3.0,          \
                yellow, thickness = 7)

    ((text_x, text_y), baseline) = cv2.getTextSize(s2, fontFace,fontScale,fontThickness)
    org = ((width - text_x) / 2, ((2 * height) / 3) + (text_y / 2)-100)
    cv2.putText(splash_array, s2, org, cv2.FONT_HERSHEY_SIMPLEX, 3.0,          \
                yellow, thickness = 7)

    #splash_image = cv.fromarray(splash_array)

    # 3ms wait
    cv2.waitKey(3)

    msg = cv_bridge.CvBridge().cv2_to_imgmsg(splash_array, encoding="bgr8")
    pub.publish(msg)

def overlayImage(s1,s2):
    splash_array= cv2.imread(images+"template6.png")
    #splash_array = numpy.zeros((self.height, self.width, 3), numpy.uint8)
    #font = cv2.InitFont(cv2.CV_FONT_HERSHEY_SIMPLEX, 3.0, 3.0, 9)
    fontFace = cv2.FONT_HERSHEY_SIMPLEX
    fontScale = 2.5
    fontThickness=7
    fontColor = (255, 255, 255)        

    ((text_x, text_y), baseline) = cv2.getTextSize(s1, fontFace,fontScale,fontThickness)
    org = ((width - text_x) / 2, (height / 3) + (text_y / 2)-100)
    cv2.putText(splash_array, s1, org, cv2.FONT_HERSHEY_SIMPLEX, 2.5,          \
                yellow, thickness = 7)

    ((text_x, text_y), baseline) = cv2.getTextSize(s2, fontFace,fontScale,fontThickness)
    org = ((width - text_x) / 2, ((2 * height) / 3) + (text_y / 2)-100)
    cv2.putText(splash_array, s2, org, cv2.FONT_HERSHEY_SIMPLEX, 2.5,          \
                yellow, thickness = 7)

    #splash_image = cv.fromarray(splash_array)
    
    joystick_image=cv2.imread(images+"500px-Joystick.png")
    x_offset=0
    y_offset=373

    splash_array[y_offset:y_offset+joystick_image.shape[0],x_offset:x_offset+joystick_image.shape[1]]=joystick_image
    # 3ms wait
    cv2.waitKey(3)

    msg = cv_bridge.CvBridge().cv2_to_imgmsg(splash_array, encoding="bgr8")
    pub.publish(msg)
    
# display lower font message on head display
def splash_screen1(s1):
    splash_array= cv2.imread(images+"template6.png")
    #splash_array = numpy.zeros((self.height, self.width, 3), numpy.uint8)

    fontFace = cv2.FONT_HERSHEY_SIMPLEX
    fontScale = 1.8
    fontThickness=3      
    ((text_x, text_y), baseline) = cv2.getTextSize("Sawyer Joystick(Xbox) Control", fontFace,fontScale,fontThickness)
    org = ((width - text_x) / 2, (height / 3) + (text_y / 2)-100)
    cv2.putText(splash_array, "Sawyer Joystick(Xbox) Control", (30,38), cv2.FONT_HERSHEY_SIMPLEX, 1.8,          \
                yellow, thickness = 3)
    org=(30,30)
    y0,dy=50,25

    for i, txt in enumerate(s1.split('\n')): 
        y = y0+i*dy 
        cv2.putText(splash_array, txt, (50, y), cv2.FONT_HERSHEY_SIMPLEX, 1, customColor, 2, 1) 


    # 3ms wait
    cv2.waitKey(3)

    msg = cv_bridge.CvBridge().cv2_to_imgmsg(splash_array, encoding="bgr8")
    pub.publish(msg)
    rospy.sleep(2)    
    
def main():
    global rgripper_open, lgripper_open
    """CSDK Joint Position Example: Joystick Control

    Use a game controller to control the angular joint positions
    of Baxter's arms.

    Attach a game controller to your dev machine and run this
    example along with the ROS joy_node to control the position
    of each joint in Baxter's arms using the joysticks. Be sure to
    provide your *joystick* type to setup appropriate key mappings.

    Each stick axis maps to a joint angle; which joints are currently
    controlled can be incremented by using the mapped increment buttons.
    Ex:
      (x,y -> e0,e1) >>increment>> (x,y -> e1,e2)
    """
    epilog = """
See help inside the example with the "Start" button for controller
key bindings.
    """
    arg_fmt = argparse.RawDescriptionHelpFormatter
    parser = argparse.ArgumentParser(formatter_class=arg_fmt,
                                     description=main.__doc__,
                                     epilog=epilog)
    required = parser.add_argument_group('required arguments')
    required.add_argument(
        '-j', '--joystick', required=True,
        choices=['xbox', 'logitech', 'ps3'],
        help='specify the type of joystick to use'
    )
    args = parser.parse_args(rospy.myargv()[1:])

    joystick = None
    if args.joystick == 'xbox':
        joystick = baxter_demos.joystick.XboxController()
    elif args.joystick == 'logitech':
        joystick = baxter_demos.joystick.LogitechController()
    elif args.joystick == 'ps3':
        joystick = baxter_demos.joystick.PS3Controller()
    else:
        parser.error("Unsupported joystick type '%s'" % (args.joystick))

    print("Initializing node... ")
    rospy.init_node("rsdk_joint_position_joystick")
    print("Getting robot state... ")
    rs = baxter_interface.RobotEnable(CHECK_VERSION)
    init_state = rs.state().enabled

    def clean_shutdown():
        print("\nExiting example.")
        if not init_state:
            print("Disabling robot...")
            rs.disable()
    rospy.on_shutdown(clean_shutdown)

    print("Enabling robot... ")
    rs.enable()

    l_gripper = baxter_interface.Gripper('left', CHECK_VERSION)
    r_gripper = baxter_interface.Gripper('right', CHECK_VERSION)    
    l_gripper.open()
    #splash_screen("left gripper " , "opened ")
    lgripper_open=1
    
    r_gripper.open()
    #splash_screen("right gripper " , "opened ")
    rgripper_open=1     

    map_joystick(joystick)
    print("Done.")

if __name__ == '__main__':
    main()

